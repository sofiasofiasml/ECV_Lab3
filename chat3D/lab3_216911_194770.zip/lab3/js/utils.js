
function query(path){
	return document.querySelector(path)
}




